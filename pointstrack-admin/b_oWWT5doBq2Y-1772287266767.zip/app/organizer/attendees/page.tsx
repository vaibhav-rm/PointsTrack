'use client'

import { motion } from 'framer-motion'
import { Search, Mail, CheckCircle, Clock } from 'lucide-react'
import { useState } from 'react'

export default function AttendeesPage() {
  const [searchTerm, setSearchTerm] = useState('')

  const attendees = [
    {
      id: 1,
      name: 'Sarah Johnson',
      email: 'sarah@company.com',
      event: 'Tech Conference 2024',
      checkIn: '9:15 AM',
      engagement: 'High',
      status: 'checked-in'
    },
    {
      id: 2,
      name: 'Michael Chen',
      email: 'michael@company.com',
      event: 'Tech Conference 2024',
      checkIn: '9:42 AM',
      engagement: 'High',
      status: 'checked-in'
    },
    {
      id: 3,
      name: 'Emily Rodriguez',
      email: 'emily@company.com',
      event: 'Web Summit',
      checkIn: '10:05 AM',
      engagement: 'Medium',
      status: 'checked-in'
    },
    {
      id: 4,
      name: 'James Wilson',
      email: 'james@company.com',
      event: 'Tech Conference 2024',
      checkIn: 'Pending',
      engagement: 'Low',
      status: 'pending'
    },
    {
      id: 5,
      name: 'Lisa Anderson',
      email: 'lisa@company.com',
      event: 'Design Workshop',
      checkIn: '2:30 PM',
      engagement: 'High',
      status: 'checked-in'
    },
  ]

  const filteredAttendees = attendees.filter(a =>
    a.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    a.email.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-4xl font-bold text-white mb-2">Attendees</h1>
        <p className="text-slate-300">Manage and track all event attendees</p>
      </motion.div>

      {/* Search Bar */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
        className="backdrop-blur-md bg-white/10 dark:bg-slate-900/30 border border-white/20 dark:border-slate-700/30 rounded-xl p-4"
      >
        <div className="relative">
          <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
          <input
            type="text"
            placeholder="Search by name or email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-lg bg-slate-800/50 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500"
          />
        </div>
      </motion.div>

      {/* Attendees Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="backdrop-blur-md bg-white/10 dark:bg-slate-900/30 border border-white/20 dark:border-slate-700/30 rounded-xl overflow-hidden"
      >
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-800">
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Name</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Event</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Check-in</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Engagement</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredAttendees.map((attendee, index) => (
                <tr
                  key={attendee.id}
                  className="border-b border-slate-800/50 hover:bg-slate-800/30 transition-colors"
                >
                  <td className="px-6 py-4">
                    <div>
                      <p className="font-medium text-white">{attendee.name}</p>
                      <p className="text-sm text-slate-400 flex items-center gap-1">
                        <Mail className="w-3 h-3" />
                        {attendee.email}
                      </p>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-slate-300">{attendee.event}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-slate-300">
                      <Clock className="w-4 h-4" />
                      {attendee.checkIn}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      attendee.engagement === 'High'
                        ? 'bg-green-500/20 text-green-400'
                        : attendee.engagement === 'Medium'
                        ? 'bg-blue-500/20 text-blue-400'
                        : 'bg-slate-700/50 text-slate-300'
                    }`}>
                      {attendee.engagement}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      {attendee.status === 'checked-in' ? (
                        <>
                          <CheckCircle className="w-4 h-4 text-green-400" />
                          <span className="text-green-400">Checked in</span>
                        </>
                      ) : (
                        <>
                          <Clock className="w-4 h-4 text-yellow-400" />
                          <span className="text-yellow-400">Pending</span>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Stats Summary */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
        className="grid md:grid-cols-3 gap-6"
      >
        <div className="backdrop-blur-md bg-white/10 dark:bg-slate-900/30 border border-white/20 dark:border-slate-700/30 rounded-xl p-6">
          <p className="text-slate-400 text-sm mb-1">Total Attendees</p>
          <p className="text-3xl font-bold text-white">{filteredAttendees.length}</p>
        </div>
        <div className="backdrop-blur-md bg-white/10 dark:bg-slate-900/30 border border-white/20 dark:border-slate-700/30 rounded-xl p-6">
          <p className="text-slate-400 text-sm mb-1">Checked In</p>
          <p className="text-3xl font-bold text-green-400">{filteredAttendees.filter(a => a.status === 'checked-in').length}</p>
        </div>
        <div className="backdrop-blur-md bg-white/10 dark:bg-slate-900/30 border border-white/20 dark:border-slate-700/30 rounded-xl p-6">
          <p className="text-slate-400 text-sm mb-1">Pending</p>
          <p className="text-3xl font-bold text-yellow-400">{filteredAttendees.filter(a => a.status === 'pending').length}</p>
        </div>
      </motion.div>
    </div>
  )
}
