'use client'

import { motion } from 'framer-motion'
import Link from 'next/link'
import { Users, Calendar, TrendingUp, Activity } from 'lucide-react'

export default function DashboardPage() {
  const stats = [
    { label: 'Total Events', value: '12', icon: Calendar, color: 'from-blue-500 to-blue-600' },
    { label: 'Active Attendees', value: '2,847', icon: Users, color: 'from-cyan-500 to-cyan-600' },
    { label: 'Engagement Rate', value: '87%', icon: TrendingUp, color: 'from-purple-500 to-purple-600' },
    { label: 'Avg. Check-in Time', value: '2.3s', icon: Activity, color: 'from-pink-500 to-pink-600' },
  ]

  const recentEvents = [
    { id: 1, name: 'Tech Conference 2024', date: 'Mar 15, 2024', attendees: 523, status: 'active' },
    { id: 2, name: 'Web Summit', date: 'Mar 10, 2024', attendees: 1204, status: 'completed' },
    { id: 3, name: 'Design Workshop', date: 'Mar 5, 2024', attendees: 89, status: 'completed' },
  ]

  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Dashboard</h1>
            <p className="text-slate-300">Welcome back! Here's your event overview.</p>
          </div>
          <Link href="/organizer/events/create" className="px-6 py-2 rounded-lg font-medium transition-all duration-300 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white hover:scale-105 hover:-translate-y-1 w-fit">
            Create Event
          </Link>
        </div>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid md:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            className="backdrop-blur-md bg-white/10 dark:bg-slate-900/30 border border-white/20 dark:border-slate-700/30 rounded-xl p-6 transition-all duration-300 hover:scale-105 hover:-translate-y-1"
          >
            <div className="flex items-start justify-between mb-4">
              <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                <stat.icon className="w-6 h-6 text-white" />
              </div>
            </div>
            <p className="text-slate-400 text-sm mb-1">{stat.label}</p>
            <p className="text-3xl font-bold text-white">{stat.value}</p>
          </motion.div>
        ))}
      </div>

      {/* Recent Events */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.4 }}
        className="backdrop-blur-md bg-white/10 dark:bg-slate-900/30 border border-white/20 dark:border-slate-700/30 rounded-xl p-6"
      >
        <h2 className="text-2xl font-bold text-white mb-6">Recent Events</h2>
        <div className="space-y-4">
          {recentEvents.map((event) => (
            <div
              key={event.id}
              className="flex items-center justify-between p-4 rounded-lg hover:bg-slate-800/30 transition-colors border border-slate-800/50"
            >
              <div>
                <h3 className="font-semibold text-white mb-1">{event.name}</h3>
                <p className="text-sm text-slate-400">{event.date}</p>
              </div>
              <div className="flex items-center gap-6">
                <div className="text-right">
                  <p className="font-semibold text-white">{event.attendees}</p>
                  <p className="text-xs text-slate-400">attendees</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                  event.status === 'active'
                    ? 'bg-green-500/20 text-green-400'
                    : 'bg-slate-700/50 text-slate-300'
                }`}>
                  {event.status === 'active' ? 'Active' : 'Completed'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Quick Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.5 }}
        className="grid md:grid-cols-3 gap-6"
      >
        <Link href="/organizer/events/create" className="glass-effect rounded-xl p-6 transition-all duration-300 hover:scale-105 hover:-translate-y-1 text-center">
          <div className="text-4xl mb-3">🎉</div>
          <h3 className="font-semibold text-white mb-2">Create Event</h3>
          <p className="text-sm text-slate-400">Set up a new event</p>
        </Link>
        <Link href="/organizer/analytics" className="glass-effect rounded-xl p-6 transition-all duration-300 hover:scale-105 hover:-translate-y-1 text-center">
          <div className="text-4xl mb-3">📊</div>
          <h3 className="font-semibold text-white mb-2">View Analytics</h3>
          <p className="text-sm text-slate-400">Detailed event insights</p>
        </Link>
        <Link href="/organizer/attendees" className="glass-effect rounded-xl p-6 transition-all duration-300 hover:scale-105 hover:-translate-y-1 text-center">
          <div className="text-4xl mb-3">👥</div>
          <h3 className="font-semibold text-white mb-2">Manage Attendees</h3>
          <p className="text-sm text-slate-400">View all attendees</p>
        </Link>
      </motion.div>
    </div>
  )
}
