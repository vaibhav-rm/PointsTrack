'use client'

import { motion } from 'framer-motion'
import Link from 'next/link'
import { Calendar, Users, MapPin, Clock } from 'lucide-react'

export default function EventsPage() {
  const events = [
    {
      id: 1,
      name: 'Tech Conference 2024',
      date: 'Mar 15, 2024',
      location: 'San Francisco, CA',
      time: '9:00 AM - 6:00 PM',
      attendees: 523,
      status: 'active'
    },
    {
      id: 2,
      name: 'Web Summit',
      date: 'Mar 10, 2024',
      location: 'New York, NY',
      time: '10:00 AM - 5:00 PM',
      attendees: 1204,
      status: 'completed'
    },
    {
      id: 3,
      name: 'Design Workshop',
      date: 'Mar 5, 2024',
      location: 'Los Angeles, CA',
      time: '2:00 PM - 4:00 PM',
      attendees: 89,
      status: 'completed'
    },
  ]

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Events</h1>
            <p className="text-slate-300">Manage and track all your events</p>
          </div>
          <Link href="/organizer/events/create" className="px-6 py-2 rounded-lg font-medium transition-all duration-300 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white hover:scale-105 hover:-translate-y-1 w-fit">
            Create New Event
          </Link>
        </div>
      </motion.div>

      <div className="space-y-4">
        {events.map((event, index) => (
          <motion.div
            key={event.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            className="backdrop-blur-md bg-white/10 dark:bg-slate-900/30 border border-white/20 dark:border-slate-700/30 rounded-xl p-6 transition-all duration-300 hover:scale-105 hover:-translate-y-1"
          >
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div className="flex-1">
                <h3 className="text-xl font-bold text-white mb-3">{event.name}</h3>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-slate-300">
                    <Calendar className="w-4 h-4" />
                    <span>{event.date}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-300">
                    <Clock className="w-4 h-4" />
                    <span>{event.time}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-300">
                    <MapPin className="w-4 h-4" />
                    <span>{event.location}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-300">
                    <Users className="w-4 h-4" />
                    <span>{event.attendees} attendees</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <span className={`px-4 py-2 rounded-lg font-medium ${
                  event.status === 'active'
                    ? 'bg-green-500/20 text-green-400'
                    : 'bg-slate-700/50 text-slate-300'
                }`}>
                  {event.status === 'active' ? 'Active' : 'Completed'}
                </span>
                <button className="px-4 py-2 rounded-lg font-medium transition-all duration-300 backdrop-blur-md bg-white/10 dark:bg-slate-900/30 border border-white/20 dark:border-slate-700/30 text-foreground hover:backdrop-blur-lg">
                  View Details
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
