'use client'

import { motion } from 'framer-motion'

export default function Showcase() {
  return (
    <section className="py-20 px-4 bg-slate-950">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-white">
            See It In Action
          </h2>
          <p className="text-lg text-slate-300">
            Explore how ACTRACK transforms event management
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="grid md:grid-cols-2 gap-8"
        >
          {/* Dashboard showcase */}
          <div className="backdrop-blur-md bg-white/10 dark:bg-slate-900/30 border border-white/20 dark:border-slate-700/30 rounded-xl overflow-hidden shadow-lg dark:shadow-blue-500/20">
            <div className="aspect-video bg-gradient-to-br from-blue-900/30 to-slate-900/30 flex items-center justify-center relative overflow-hidden">
              <div className="absolute inset-0 grid grid-cols-4 grid-rows-4 gap-px opacity-10">
                {Array.from({ length: 16 }).map((_, i) => (
                  <div key={i} className="bg-cyan-500" />
                ))}
              </div>
              <div className="relative text-center">
                <div className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">
                  2,847
                </div>
                <p className="text-slate-300 text-sm mt-2">Attendees Tracked</p>
              </div>
            </div>
          </div>

          {/* Analytics showcase */}
          <div className="backdrop-blur-md bg-white/10 dark:bg-slate-900/30 border border-white/20 dark:border-slate-700/30 rounded-xl overflow-hidden shadow-lg dark:shadow-blue-500/20">
            <div className="aspect-video bg-gradient-to-br from-cyan-900/30 to-slate-900/30 flex items-center justify-center relative overflow-hidden">
              <div className="space-y-4 w-full px-8">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-300">Check-ins</span>
                  <div className="h-2 w-24 rounded-full bg-slate-700 overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-blue-500 to-cyan-500 w-[92%]" />
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-300">Engagement</span>
                  <div className="h-2 w-24 rounded-full bg-slate-700 overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-blue-500 to-cyan-500 w-[78%]" />
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-300">Conversions</span>
                  <div className="h-2 w-24 rounded-full bg-slate-700 overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-blue-500 to-cyan-500 w-[65%]" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
